from http.server import BaseHTTPRequestHandler, HTTPServer
import cgi



class MyAPIHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'''
            <html>
            <body>
            <h1>This my server API.</h1>
            <form method="POST">
            <label>Enter your name:</label>
            <input type="text" name="name">
            <input type="submit" value="Submit">
            </form>
            </body>
            </html>
            ''')

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        form_data = cgi.parse_qs(post_data.decode())
        name = form_data["name"][0]

        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(f"<html><body><h1>Hello, {name}!</h1></body></html>".encode())


def run_server(port):
    httpd = HTTPServer(('localhost', port), MyAPIHandler)
    print('Listening on port', port)
    httpd.serve_forever()


if __name__ == '__main__':
    run_server(3000)
