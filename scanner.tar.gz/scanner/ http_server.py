from http.server import HTTPServer, BaseHTTPRequestHandler

# def run(server_class=HTTPServer, handler_class=BaseHTTPRequestHandler):
#     server_address = ('localhost', 8000)
#     httpd = server_class(server_address, handler_class)
#     httpd.serve_forever()

class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    # определяем метод `do_GET`
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'Hello, world!')
httpd = HTTPServer(('localhost', 8000), SimpleHTTPRequestHandler)
httpd.serve_forever()
